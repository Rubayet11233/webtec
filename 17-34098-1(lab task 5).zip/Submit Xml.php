<?php
	$username = $_POST["userName"];
	$pass = $_POST["password"];
    $flag = false;
    $xml = simplexml_load_file("Users.xml");
    
    foreach($xml->user as $user){
        if(($user->username == "nur") && ($user->pass == "123")){
            $flag = true;
            break;
        }
    }

    
	if($flag){
		echo "Login Successfully";
	}
	else{
		echo "username of password is not correct, Try again!!!";
	}
?>