<html>
	<head>
		<title>Problem_1</title>
	</head>
	
	<body>
		A quick brown
		<?php
			echo "<b>fox</b>"
		?>
		jumps over the lazy
		<?php
			echo "<b>dog</b>"
		?>
	</body>
</html>