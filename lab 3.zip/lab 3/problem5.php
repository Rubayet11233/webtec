<html>
	<head>
		<title>Problem_5</title>
	</head>
	
	<body>
		<?php
			$backColor="green"; 
			$fontColor="red"; 
			$imageWidth="80px"; 
			$imageHeight="80px";
		?>
		
		<img src="aiub_logo.jpg" width="<?php echo $imageWidth?>" height="<?php echo $imageHeight?>"/>
		
		<h2 style="display: inline;">American International University -<span style="background-color:<?php echo $backColor?>;color:<?php echo $fontColor?>">Bangladesh</span></h2>
		
	</body>
</html>