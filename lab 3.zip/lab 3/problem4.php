<html>
	<head>
		<title>Problem_4</title>
	</head>
	
	<body>
		<?php
		
			$name = "mithu";
			
			if($name == "raju" or $name == "mina" or $name == "mithu"){
				echo "<b>hello</b>";
			}
			else{
				echo "<span style= 'color:red'>you are not recognized</span>";
			}
		?>
	</body>
</html>