<html>
	<head></head>
	<body>
		<h2>Welcome <?php echo $_COOKIE["Loggedinuser"];?> You are a <?php echo $_COOKIE["type"];?>
	</body>
</html>